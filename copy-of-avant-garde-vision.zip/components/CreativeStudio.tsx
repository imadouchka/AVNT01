
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { CreativeBrief } from '../types';

const CreativeStudio: React.FC = () => {
  const [keyword, setKeyword] = useState('');
  const [mood, setMood] = useState<'dark' | 'neon' | 'minimalist' | 'chaotic'>('minimalist');
  const [loading, setLoading] = useState(false);
  const [brief, setBrief] = useState<CreativeBrief | null>(null);

  const generateBrief = async () => {
    if (!keyword) return;
    setLoading(true);
    setBrief(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Act as a creative director for an avant-garde motion graphics and film studio. Generate a visionary creative brief for a project based on the keyword "${keyword}" with a "${mood}" mood. Be poetic and highly technical.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              visualLanguage: { type: Type.STRING },
              motionTheory: { type: Type.STRING },
              colorPalette: { 
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ['title', 'visualLanguage', 'motionTheory', 'colorPalette']
          }
        }
      });

      const result = JSON.parse(response.text.trim());
      setBrief(result);
    } catch (error) {
      console.error("Failed to generate brief", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#0e0e0e] border border-white/5 p-8 md:p-12 rounded-lg">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div>
            <label className="block text-[10px] uppercase tracking-[0.3em] text-zinc-500 mb-4 font-bold">Project Nucleus</label>
            <input 
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="E.g. Quantum Silence, Digital Decay..."
              className="w-full bg-transparent border-b border-zinc-800 py-4 text-xl focus:outline-none focus:border-orange-500 transition-colors uppercase font-syncopate"
            />
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-[0.3em] text-zinc-500 mb-4 font-bold">Atmospheric Flux</label>
            <div className="grid grid-cols-2 gap-4">
              {(['minimalist', 'dark', 'neon', 'chaotic'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMood(m)}
                  className={`py-3 text-[10px] uppercase tracking-widest font-bold border ${
                    mood === m ? 'bg-orange-500 border-orange-500 text-white' : 'border-zinc-800 text-zinc-500 hover:border-zinc-600'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={generateBrief}
            disabled={loading || !keyword}
            className="w-full bg-white text-black py-4 uppercase tracking-[0.3em] font-black hover:bg-orange-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Synthesizing...' : 'Initialize Generation'}
          </button>
        </div>

        <div className="min-h-[300px] flex flex-col justify-center border border-white/5 bg-black/50 p-8 rounded relative overflow-hidden">
          {!brief && !loading && (
            <div className="text-center space-y-4">
              <div className="text-zinc-800 font-syncopate text-6xl select-none">VOID</div>
              <p className="text-zinc-600 text-xs uppercase tracking-widest">Awaiting algorithmic input</p>
            </div>
          )}

          {loading && (
            <div className="space-y-4 animate-pulse">
              <div className="h-8 bg-zinc-900 w-3/4"></div>
              <div className="h-32 bg-zinc-900 w-full"></div>
              <div className="h-4 bg-zinc-900 w-1/2"></div>
            </div>
          )}

          {brief && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
              <h3 className="text-2xl font-syncopate font-bold text-orange-500 uppercase">{brief.title}</h3>
              
              <div>
                <h4 className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-2">Visual Ethos</h4>
                <p className="text-sm text-zinc-300 leading-relaxed italic">"{brief.visualLanguage}"</p>
              </div>

              <div>
                <h4 className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-2">Motion Dynamics</h4>
                <p className="text-sm text-zinc-300 leading-relaxed">{brief.motionTheory}</p>
              </div>

              <div>
                <h4 className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-2">Chromatic Array</h4>
                <div className="flex space-x-2">
                  {brief.colorPalette.map((color, idx) => (
                    <div 
                      key={idx} 
                      className="w-12 h-4 rounded-sm border border-white/10" 
                      style={{ backgroundColor: color }}
                      title={color}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Abstract Scanlines */}
          <div className="absolute inset-0 pointer-events-none opacity-5 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
        </div>
      </div>
    </div>
  );
};

export default CreativeStudio;
