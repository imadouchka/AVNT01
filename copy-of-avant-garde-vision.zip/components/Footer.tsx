
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-24 px-6 md:px-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-16">
        <div className="max-w-xl">
          <h2 className="text-4xl md:text-6xl font-syncopate font-bold uppercase mb-8 tracking-tighter leading-none">
            Let's Shape <br /> The <span className="text-orange-500">Static.</span>
          </h2>
          <p className="text-zinc-500 text-lg uppercase tracking-widest font-bold">
            Currently accepting commissions for late 2024 / 2025.
          </p>
        </div>
        
        <div className="flex flex-col md:items-end space-y-12">
          <div className="grid grid-cols-2 gap-x-16 gap-y-4">
            <div>
              <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-600 font-bold mb-4">Connect</p>
              <ul className="space-y-2">
                {['Instagram', 'Vimeo', 'LinkedIn', 'Behance'].map(s => (
                  <li key={s}><a href="#" className="text-sm uppercase tracking-widest font-bold hover:text-orange-500 transition-colors">{s}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-600 font-bold mb-4">Contact</p>
              <ul className="space-y-2">
                <li><a href="mailto:hello@avnt.lab" className="text-sm uppercase tracking-widest font-bold hover:text-orange-500 transition-colors">hello@avnt.lab</a></li>
                <li><p className="text-sm uppercase tracking-widest font-bold text-zinc-400">+1 000 123 4567</p></li>
              </ul>
            </div>
          </div>
          
          <div className="text-[10px] uppercase tracking-[0.4em] text-zinc-700 font-bold text-right">
            © 2024 AVANT-GARDE STUDIO / ALL RIGHTS RESERVED
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
