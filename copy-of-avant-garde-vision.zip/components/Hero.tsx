
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen flex flex-col justify-center items-start px-6 md:px-12 overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-1/4 right-0 w-1/2 h-1/2 border-l border-t border-white/5 -z-10" />
      <div className="absolute bottom-1/4 left-0 w-1/3 h-1/3 border-r border-b border-white/5 -z-10" />
      
      <div className="z-10 max-w-5xl">
        <div className="mb-6 overflow-hidden">
          <span className="inline-block text-orange-500 text-sm md:text-base font-bold tracking-[0.3em] uppercase animate-pulse">
            Avant-Garde Motion & Film Studio
          </span>
        </div>
        
        <h1 className="text-7xl md:text-[10rem] font-syncopate font-bold leading-[0.85] tracking-tighter uppercase mb-8">
          Crafting <br /> 
          <span className="text-transparent border-t-4 border-b-4 border-white py-2" style={{ WebkitTextStroke: '1px white' }}>Movement</span> <br />
          In Chaos.
        </h1>
        
        <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-12 mt-12">
          <p className="text-xl md:text-2xl text-zinc-400 max-w-xl font-light leading-snug">
            We are a high-performance visual lab specializing in motion design, deep infographics, and disruptive film editing for the next era of digital storytelling.
          </p>
          
          <div className="relative group cursor-pointer" onClick={() => {
            const el = document.getElementById('portfolio');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}>
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border border-white/20 flex items-center justify-center transition-all group-hover:bg-white group-hover:scale-110">
              <svg className="w-8 h-8 text-white group-hover:text-black transition-colors transform rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </div>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] uppercase tracking-[0.4em] opacity-40 group-hover:opacity-100 transition-opacity">
              Explore Works
            </span>
          </div>
        </div>
      </div>

      {/* Side Label */}
      <div className="absolute right-6 top-1/2 -translate-y-1/2 rotate-90 origin-right hidden lg:block">
        <span className="text-[10px] uppercase tracking-[1em] text-zinc-600 whitespace-nowrap">
          Creative Excellence Since 2024
        </span>
      </div>
    </div>
  );
};

export default Hero;
