
import React from 'react';

interface NavbarProps {
  activeSection: string;
}

const Navbar: React.FC<NavbarProps> = ({ activeSection }) => {
  const navItems = [
    { id: 'home', label: 'Index' },
    { id: 'portfolio', label: 'Work' },
    { id: 'skills', label: 'Systems' },
    { id: 'studio', label: 'Lab' },
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth',
      });
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-50 mix-blend-difference px-6 md:px-12 py-8 flex justify-between items-center pointer-events-none">
      <div className="pointer-events-auto">
        <button 
          onClick={() => scrollToSection('home')}
          className="text-2xl font-syncopate font-bold tracking-tighter text-white"
        >
          AVNT<span className="text-orange-500">.</span>
        </button>
      </div>

      <div className="hidden md:flex space-x-12 pointer-events-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => scrollToSection(item.id)}
            className={`text-sm uppercase tracking-widest font-bold transition-all hover:text-orange-500 ${
              activeSection === item.id ? 'text-orange-500 underline underline-offset-8' : 'text-white/60'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="pointer-events-auto">
        <button className="bg-white text-black px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-colors">
          Contact
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
