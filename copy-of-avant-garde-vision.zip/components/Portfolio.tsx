
import React, { useState } from 'react';
import { PROJECTS } from '../constants';
import { Category, Project } from '../types';

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState<Category | 'All'>('All');
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  const categories: (Category | 'All')[] = ['All', 'Motion', 'Infographics', 'Editing'];
  const filteredProjects = filter === 'All' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === filter);

  return (
    <div>
      <div className="flex flex-wrap gap-4 mb-12">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-8 py-2 text-xs font-bold uppercase tracking-widest border transition-all ${
              filter === cat ? 'bg-white text-black border-white' : 'text-zinc-500 border-zinc-800 hover:border-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
        {filteredProjects.map((project) => (
          <div 
            key={project.id}
            className="group relative"
            onMouseEnter={() => setHoveredProject(project.id)}
            onMouseLeave={() => setHoveredProject(null)}
          >
            <div className="relative aspect-video overflow-hidden bg-zinc-900 border border-white/5">
              <img 
                src={project.thumbnailUrl} 
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60 group-hover:opacity-100"
              />
              
              {/* Video Preview Overlay on Hover (Simulation) */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                 <div className="w-12 h-12 border border-white/50 rounded-full flex items-center justify-center">
                    <div className="w-0 h-0 border-t-8 border-t-transparent border-l-[12px] border-l-white border-b-8 border-b-transparent ml-1" />
                 </div>
              </div>

              {/* Tag Overlays */}
              <div className="absolute top-4 right-4 flex flex-col space-y-2">
                {project.tags.slice(0, 1).map(tag => (
                   <span key={tag} className="text-[9px] bg-black/80 text-white px-2 py-1 uppercase tracking-wider backdrop-blur-sm border border-white/10">
                    {tag}
                   </span>
                ))}
              </div>
            </div>

            <div className="mt-6 flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold uppercase tracking-tight group-hover:text-orange-500 transition-colors">
                  {project.title}
                </h3>
                <p className="text-xs text-zinc-500 mt-1 uppercase tracking-widest font-bold">
                  {project.category}
                </p>
              </div>
              <span className="text-zinc-800 text-3xl font-syncopate font-black">
                /0{project.id}
              </span>
            </div>
            
            <p className="mt-4 text-zinc-400 text-sm leading-relaxed max-w-sm">
              {project.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Portfolio;
