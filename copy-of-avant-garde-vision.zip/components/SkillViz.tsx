
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { SKILLS } from '../constants';

const SkillViz: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 500;
    const height = 500;
    const margin = 50;
    const radius = Math.min(width, height) / 2 - margin;

    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .html(""); // Clear existing

    const g = svg.append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    const angleScale = d3.scaleLinear()
      .domain([0, SKILLS.length])
      .range([0, 2 * Math.PI]);

    const radiusScale = d3.scaleLinear()
      .domain([0, 100])
      .range([0, radius]);

    // Draw Grid (Circles)
    const levels = [20, 40, 60, 80, 100];
    g.selectAll('.grid-circle')
      .data(levels)
      .enter()
      .append('circle')
      .attr('r', d => radiusScale(d))
      .attr('fill', 'none')
      .attr('stroke', '#1a1a1a')
      .attr('stroke-width', 1);

    // Draw Axes (Lines)
    SKILLS.forEach((s, i) => {
      const angle = angleScale(i);
      g.append('line')
        .attr('x1', 0)
        .attr('y1', 0)
        .attr('x2', radiusScale(100) * Math.cos(angle - Math.PI / 2))
        .attr('y2', radiusScale(100) * Math.sin(angle - Math.PI / 2))
        .attr('stroke', '#1a1a1a');

      // Add Labels
      const labelRadius = radiusScale(115);
      g.append('text')
        .attr('x', labelRadius * Math.cos(angle - Math.PI / 2))
        .attr('y', labelRadius * Math.sin(angle - Math.PI / 2))
        .attr('text-anchor', 'middle')
        .attr('fill', '#666')
        .attr('font-size', '10px')
        .attr('font-weight', 'bold')
        .attr('letter-spacing', '2px')
        .text(s.name.toUpperCase());
    });

    // Draw Data Shape
    const radarLine = d3.lineRadial<any>()
      .angle((d, i) => angleScale(i))
      .radius(d => radiusScale(d.value))
      .curve(d3.curveLinearClosed);

    g.append('path')
      .datum(SKILLS)
      .attr('d', radarLine)
      .attr('fill', 'rgba(255, 62, 0, 0.1)')
      .attr('stroke', '#ff3e00')
      .attr('stroke-width', 2)
      .attr('stroke-dasharray', function() {
        const length = this.getTotalLength();
        return `${length} ${length}`;
      })
      .attr('stroke-dashoffset', function() {
        return this.getTotalLength();
      })
      .transition()
      .duration(2000)
      .attr('stroke-dashoffset', 0);

    // Add points
    g.selectAll('.point')
      .data(SKILLS)
      .enter()
      .append('circle')
      .attr('cx', (d, i) => radiusScale(d.value) * Math.cos(angleScale(i) - Math.PI / 2))
      .attr('cy', (d, i) => radiusScale(d.value) * Math.sin(angleScale(i) - Math.PI / 2))
      .attr('r', 4)
      .attr('fill', '#fff')
      .attr('stroke', '#ff3e00')
      .attr('stroke-width', 2);

  }, []);

  return (
    <div className="w-full h-full flex items-center justify-center">
      <svg ref={svgRef} className="w-full h-full max-w-[500px]" />
    </div>
  );
};

export default SkillViz;
