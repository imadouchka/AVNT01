
import { Project } from './types';

export const PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Kinetic Brutalism',
    category: 'Motion',
    description: 'Exploration of heavy typography and rigid structural movement in a digital space.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-abstract-movement-of-a-blue-and-red-liquid-4411-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/kinetic/800/600',
    tags: ['After Effects', 'C4D', 'Typography']
  },
  {
    id: '2',
    title: 'Data Flow 2024',
    category: 'Infographics',
    description: 'Real-time visualization of global climate patterns converted into abstract art.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-abstract-lines-and-particles-2041-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/data/800/600',
    tags: ['D3.js', 'Vector Art', 'Complex Data']
  },
  {
    id: '3',
    title: 'Neon Noir Edit',
    category: 'Editing',
    description: 'A rhythmic montage of urban nightscapes focusing on color-grading and pace.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-night-city-with-neon-lights-and-traffic-17865-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/neon/800/600',
    tags: ['Premiere Pro', 'DaVinci Resolve', 'Color Grading']
  },
  {
    id: '4',
    title: 'Abstract Geometry',
    category: 'Motion',
    description: 'The intersection of primitive shapes and complex physics engines.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-under-the-ocean-water-surface-4338-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/geo/800/600',
    tags: ['3D Motion', 'Houdini', 'Physics']
  },
  {
    id: '5',
    title: 'Systemic Breakdown',
    category: 'Infographics',
    description: 'A visual journey through the collapse and rebirth of digital infrastructures.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-white-cloudy-surface-background-2330-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/system/800/600',
    tags: ['Technical Illustration', 'Infographic Design']
  },
  {
    id: '6',
    title: 'The Silent Frame',
    category: 'Editing',
    description: 'Award-winning short film edit emphasizing the power of silence and long takes.',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-moving-through-a-green-forest-4113-large.mp4',
    thumbnailUrl: 'https://picsum.photos/seed/frame/800/600',
    tags: ['Narrative', 'Film Editing', 'Sound Design']
  }
];

export const SKILLS = [
  { name: 'Motion Design', value: 95 },
  { name: 'Color Grading', value: 88 },
  { name: 'Data Viz', value: 92 },
  { name: 'Editing', value: 90 },
  { name: 'Concept Art', value: 85 }
];
