
export type Category = 'Motion' | 'Infographics' | 'Editing';

export interface Project {
  id: string;
  title: string;
  category: Category;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  tags: string[];
}

export interface ConceptRequest {
  keyword: string;
  mood: 'dark' | 'neon' | 'minimalist' | 'chaotic';
}

export interface CreativeBrief {
  title: string;
  visualLanguage: string;
  motionTheory: string;
  colorPalette: string[];
}
